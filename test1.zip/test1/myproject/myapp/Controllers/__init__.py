from myapp.Controllers.ChatController import send_message
from myproject.serializers import OtpSerializer
from ..Helpers.helper import renderr
from myapp.AppLogic.GenerallService import with_request, post, get