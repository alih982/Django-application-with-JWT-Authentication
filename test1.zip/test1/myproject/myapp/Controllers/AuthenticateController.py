import sys
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from ..models import ChatMessage
from ..Helpers.helper import renderr
import logging


# class AuthenticateController():
    
#     # def authenticateUser():
        